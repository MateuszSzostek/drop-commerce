import ResetPasswordForm from "../../../identify-and-access-context/components/ResetPasswordForm/ResetPasswordForm"

export default function ResetPasswordView() {
  return <ResetPasswordForm />
}
