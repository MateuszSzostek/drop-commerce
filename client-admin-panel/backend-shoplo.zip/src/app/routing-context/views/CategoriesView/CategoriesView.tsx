import CategoriesTree from "../../../category-context/components/CategoriesTree/CategoriesTree"

export default function CategoriesView() {
  return <CategoriesTree />
}
