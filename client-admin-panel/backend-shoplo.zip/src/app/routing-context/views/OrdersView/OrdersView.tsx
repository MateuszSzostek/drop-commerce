import OrdersList from "../../../order-context/components/OrdersList/OrdersList"

export default function OrdersView() {
  return <OrdersList />
}
