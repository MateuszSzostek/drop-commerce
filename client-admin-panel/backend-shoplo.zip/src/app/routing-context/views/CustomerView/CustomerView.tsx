import Customer from "../../../customer-context/components/Customer/Customer"

export default function CustomerView() {
  return <Customer />
}
