import Order from "../../../order-context/components/Order/Order"

export default function OrderView() {
  return <Order />
}
