import ProductsList from "../../../product-context/components/ProductsList/ProductsList"

export default function ProductsView() {
  return <ProductsList />
}
