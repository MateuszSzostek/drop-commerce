import CustomersList from "../../../customer-context/components/CustomersList/CustomersList"

export default function CustomersView() {
  return <CustomersList />
}
