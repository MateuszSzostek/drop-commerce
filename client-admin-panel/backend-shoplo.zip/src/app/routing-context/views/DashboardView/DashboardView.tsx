import Dashboard from "../../../admin-dashboard-context/components/AdminDashboard/AdminDashboard"

export default function DashboardView() {
  return <Dashboard />
}
