import SignUpForm from "../../../identify-and-access-context/components/SignUpForm/SignUpForm"

export default function SignUpView() {
  return <SignUpForm />
}
