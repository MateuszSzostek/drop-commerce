import Product from "../../../product-context/components/Product/Product"

export default function ProductView() {
  return <Product />
}
