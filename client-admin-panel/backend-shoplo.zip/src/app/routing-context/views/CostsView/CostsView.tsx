export default function CostsView() {
  return <>CostsView</>
}
