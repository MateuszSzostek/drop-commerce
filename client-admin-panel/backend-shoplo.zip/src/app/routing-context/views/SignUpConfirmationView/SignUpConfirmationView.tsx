import SignUpConfirmation from "../../../identify-and-access-context/components/SignUpConfirmation/SignUpConfirmation"

export default function SignUpConfirmationView() {
  return <SignUpConfirmation />
}
