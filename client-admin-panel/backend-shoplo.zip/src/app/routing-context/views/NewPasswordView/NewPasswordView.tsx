import NewPasswordForm from "../../../identify-and-access-context/components/NewPasswordForm/NewPasswordForm"

export default function NewPasswordView() {
  return (
    <>
      <NewPasswordForm />
    </>
  )
}
