export default function InvoicesView() {
  return <>InvoicesView</>
}
