export default function ChatView() {
  return <>Chat View</>
}
