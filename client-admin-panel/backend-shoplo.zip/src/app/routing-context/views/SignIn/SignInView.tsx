import SignInForm from "../../../identify-and-access-context/components/SignInForm/SignInForm"

export default function SignInView() {
  return <SignInForm />
}
