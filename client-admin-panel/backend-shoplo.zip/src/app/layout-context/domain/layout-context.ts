export const NAVIGATION_KEYS = {
  invoices: "invoices",
  workTime: "work-time",
  reports: "reports",
  contractors: "contractors",
  profile: "profile",
  logout: "logout",
}
