import LandingLayout from "./LandingLayout"

describe("<LandingLayout />", () => {
  it("Does the landing ayout form render?", () => {
    cy.mount(<LandingLayout />)
  })
})
