import { FormProps, TableProps } from "antd"
import React, { ReactNode, useEffect, useState } from "react"

import { CategoriesTree, ICategoryNode } from "../../domain/category-context"
import CategoryNode from "../CategoryNode/CategoryNode"

export default function useCategoryNode() {
  return {}
}
