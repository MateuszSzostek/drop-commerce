import { BASE_API_URL } from "../../../common/consts/index"

/*
 *** Requests Types
 */

export type FetchAllIkonkaProductsRequest = {}

export type FetchAllIkonkaProductsResponse = {}

/*
 *** Fields Types
 */

/*
 *** Component Props Types
 */

/*
 *** Other types
 */

/*
 *** Field Types Keys
 */

export const BASE_IKONKA_URL = `${BASE_API_URL}api/ikonka/`
