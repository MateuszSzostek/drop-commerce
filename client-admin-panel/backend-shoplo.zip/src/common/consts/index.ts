export const BASE_API_URL = `${import.meta.env.VITE_BACKEND_URL}`
// import.meta.env.VITE_USE_MOCK_LOCAL_SERVER === "true" ? `${import.meta.env.VITE_FAKE_BACKEND_URL}` : `${import.meta.env.VITE_BACKEND_URL}`
