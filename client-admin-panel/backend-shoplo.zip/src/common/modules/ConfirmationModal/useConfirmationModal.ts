export default function useConfirmationModal() {
  return {}
}
