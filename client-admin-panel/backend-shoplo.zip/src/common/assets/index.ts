import reactLogo from "./image/vector/react.svg"
import exampleSvg from "./image/vector/example.svg"

import exampleJpg from "./image/raster/example.jpg"
import googleBtnIcon from "./image/raster/google-btn.png"

import userIcon from "./image/vector/user.svg"

export { reactLogo, exampleJpg, exampleSvg, googleBtnIcon, userIcon }
