import Select from "./Select"

describe("<Select />", () => {
  it("Does the select render?", () => {
    cy.mount(<Select />)
  })
})
