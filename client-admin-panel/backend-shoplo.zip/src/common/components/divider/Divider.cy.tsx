import Divider from "./Divider"

describe("<Divider />", () => {
  it("Does the divider render?", () => {
    cy.mount(<Divider />)
  })
})
