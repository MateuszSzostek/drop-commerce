import FormItem from "./FormItem"

describe("<FormItem />", () => {
  it("Does the text input render render?", () => {
    cy.mount(<FormItem />)
  })
})
