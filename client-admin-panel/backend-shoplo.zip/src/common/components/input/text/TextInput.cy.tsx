import TextInput from "./TextInput"

describe("<TextInput />", () => {
  it("Does the text input render render?", () => {
    cy.mount(<TextInput />)
  })
})
