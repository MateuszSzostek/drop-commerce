import PasswordInput from "./PasswordInput"

describe("<PasswordInput />", () => {
  it("Does the password input render render?", () => {
    cy.mount(<PasswordInput />)
  })
})
