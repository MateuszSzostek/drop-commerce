import Modal from "./Modal"

describe("<Modal />", () => {
  it("Does the modal render?", () => {
    cy.mount(<Modal />)
  })
})
