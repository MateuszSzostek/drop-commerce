export default function useCarousel() {
  return {}
}
