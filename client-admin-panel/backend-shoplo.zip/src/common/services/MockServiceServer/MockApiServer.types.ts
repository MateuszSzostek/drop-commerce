export type MockUserType = {
  email: string
  password: string
}

export type MockDatabaseType = {
  users: MockUserType[]
}
