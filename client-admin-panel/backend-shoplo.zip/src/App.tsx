import Router from "./app/routing-context/components/Router/Router"
//import "./common/services/MockServiceServer/MockApiServer.ts"

function App() {
  return (
    <>
      <Router />
    </>
  )
}

export default App
